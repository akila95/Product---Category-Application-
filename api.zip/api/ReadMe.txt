1. This rest api created in php and sql.

2. Extract the folder to your runtime environment(localhost). 

3. import given "rest_db" sql file into your database handling environment.

4. In the configuration folder all the default database configuration specified where you can change it to your own preference according to your database deployment. 

5. Inside the category folder you can find out all the relevant tasks which are create, update, delete and view categories. 

6. Inside the product folder you can find out all the relvant tasks which create, update, delete and view products which are related to various categories. 

7. using postman or anyother tool you can pass json body and insert, update, delete and view data in the application. 