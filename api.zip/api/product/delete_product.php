<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");


include ("../config/database.php");

$data = json_decode(file_get_contents("php://input"));

 
    $name = $data->name;

	$sql = "DELETE FROM products WHERE name='$name'";
	
	if ($conn->query($sql) === TRUE) {
		echo "Product Deleted successfully";
	} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
	}
?>