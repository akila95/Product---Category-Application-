<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");


include ("../config/database.php");

$data = json_decode(file_get_contents("php://input"));

 
    $name = $data->name;
    $price = $data->price;
    $description = $data->description;
    $category_id = $data->category_id;
    
	$sql = "UPDATE products SET name='$name',description='$description',price='$price',category_id='$category_id' WHERE name='$name'";
	
	if ($conn->query($sql) === TRUE) {
		echo "Product Updated successfully";
	} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
	}
?>