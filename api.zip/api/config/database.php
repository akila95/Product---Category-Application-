<?php

		
		$host = "localhost";
		$db_name = "rest_db";
		$username = "root";
		$password = "";
		$conn;

				
				if($conn = new mysqli($host, $username, $password, $db_name)){
					
					
				}else{
					
					echo "Connection Fail !";
				
				}

	
?>
					
	